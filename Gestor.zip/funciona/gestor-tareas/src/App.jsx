import { useState, useEffect } from 'react';

function App() {
  const [notas, setNotas] = useState(() => {
    const guardadas = localStorage.getItem('notas');
    return guardadas ? JSON.parse(guardadas) : [];
  });

  const [titulo, setTitulo] = useState('');
  const [contenido, setContenido] = useState('');
  const [prioridad, setPrioridad] = useState('media');
  const [fecha, setFecha] = useState('');

  useEffect(() => {
    localStorage.setItem('notas', JSON.stringify(notas));
  }, [notas]);

  const guardarEnSheet = (nota, action = "guardar") => {
    fetch("https://script.google.com/macros/s/AKfycbyoIv058OL3JfDB-rOVgVb-he5BuBjrAxaVWO1BREYKudwhrS87S1pKGAZF0w55lZhpUA/exec", {
      method: "POST",
      mode: "no-cors",
      body: JSON.stringify({ ...nota, action }),
      headers: {
        "Content-Type": "application/json"
      }
    });
  };

  const agregarNota = (e) => {
    e.preventDefault();
    if (titulo.trim() === '' || contenido.trim() === '') return;

    const nueva = {
      id: Date.now(),
      titulo,
      contenido,
      prioridad,
      fecha
    };

    setNotas([...notas, nueva]);
    guardarEnSheet(nueva);
    setTitulo('');
    setContenido('');
    setPrioridad('media');
    setFecha('');
  };

  const eliminarNota = (id) => {
    setNotas(notas.filter(n => n.id !== id));

    fetch("https://script.google.com/macros/s/AKfycbyoIv058OL3JfDB-rOVgVb-he5BuBjrAxaVWO1BREYKudwhrS87S1pKGAZF0w55lZhpUA/exec", {
      method: "POST",
      mode: "no-cors",
      body: JSON.stringify({ id, action: "eliminar" }),
      headers: { "Content-Type": "application/json" }
    });
  };

  const editarNota = (nota) => {
    setTitulo(nota.titulo);
    setContenido(nota.contenido);
    setPrioridad(nota.prioridad);
    setFecha(nota.fecha);
    setNotas(notas.filter(n => n.id !== nota.id)); // quitar la antigua
    guardarEnSheet(nota, "editar"); // enviar como acción editar
  };

  const leerNota = (nota) => {
    alert(`📌 ${nota.titulo}\n\n${nota.contenido}`);
  };

  const duplicarNota = (nota) => {
    const copia = { ...nota, id: Date.now() };
    setNotas([...notas, copia]);
    guardarEnSheet(copia);
  };

  return (
    <div style={{ fontFamily: 'Arial', maxWidth: '800px', margin: '40px auto', backgroundColor: '#f9f9f9', padding: '30px', borderRadius: '12px', boxShadow: '0 0 10px rgba(0,0,0,0.1)' }}>
      <h1 style={{ textAlign: 'center' }}>📘 Mis Notas</h1>

      <form onSubmit={agregarNota} style={{ marginBottom: '30px' }}>
        <input
          type="text"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
          placeholder="Título de la nota"
          style={{ width: '100%', padding: '10px', fontSize: '18px', marginBottom: '10px', borderRadius: '8px', border: '1px solid #ccc' }}
        />
        <textarea
          value={contenido}
          onChange={(e) => setContenido(e.target.value)}
          placeholder="Contenido de la nota..."
          style={{ width: '100%', padding: '15px', fontSize: '16px', resize: 'vertical', borderRadius: '8px', border: '1px solid #ccc', marginBottom: '10px', minHeight: '100px' }}
        />
        <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}>
          <select value={prioridad} onChange={(e) => setPrioridad(e.target.value)} style={{ padding: '10px', borderRadius: '8px', border: '1px solid #ccc' }}>
            <option value="alta">Alta</option>
            <option value="media">Media</option>
            <option value="baja">Baja</option>
          </select>
          <input
            type="date"
            value={fecha}
            onChange={(e) => setFecha(e.target.value)}
            style={{ padding: '10px', borderRadius: '8px', border: '1px solid #ccc' }}
          />
          <button type="submit" style={{ backgroundColor: '#4f46e5', color: 'white', padding: '10px 20px', border: 'none', borderRadius: '8px' }}>
            Guardar
          </button>
        </div>
      </form>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {notas.map((nota) => (
          <li key={nota.id} style={{ backgroundColor: '#fff', padding: '15px', borderRadius: '10px', marginBottom: '10px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
            <div style={{ marginBottom: '5px' }}><strong>{nota.titulo}</strong></div>
            <div style={{ color: '#555', marginBottom: '8px' }}>{nota.contenido.slice(0, 60)}...</div>
            <small style={{ color: '#888' }}>📅 {nota.fecha} — {nota.prioridad}</small>
            <div style={{ marginTop: '10px', display: 'flex', gap: '10px' }}>
              <button onClick={() => editarNota(nota)} style={{ fontSize: '14px' }}>✏️ Editar</button>
              <button onClick={() => leerNota(nota)} style={{ fontSize: '14px' }}>👁️ Leer</button>
              <button onClick={() => eliminarNota(nota.id)} style={{ fontSize: '14px', color: '#b91c1c' }}>🗑️ Eliminar</button>
              <button onClick={() => duplicarNota(nota)} style={{ fontSize: '14px' }}>📄 Duplicar</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
